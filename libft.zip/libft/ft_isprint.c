#include "libft.h"

int ft_isprint(int c)
{
    return(c >= 33 && c <= 126);
}