#include "libft.h"

void *ft_memchr(const void *str, int c, size_t n)
{
    const unsigned char *string = str;
    size_t i;

    if(!str)
    {
        return (NULL);
    }
    i = 0;
    while((string[i] != '\0') & (i < n))
    {
        if(string[i] == (unsigned char)c)
            return ((void *)(str + i));
        i++;
    }
    return (NULL);

}